# ProyectaFormosa

Asistente de proyectos áulicos para **Nivel Primario de la Provincia de Formosa** (1.° a 6.° grado). El docente elige grado y área, escribe qué necesita y recibe un proyecto completo: fundamentación, objetivos, contenidos, actividades por clase y criterios de evaluación.

> Los proyectos son borradores generados con IA. Deben revisarse con el Diseño Curricular de Educación Primaria de Formosa y los NAP antes de usarse.

## Cómo usarla

Es un único archivo HTML, sin instalación ni dependencias.

1. Abrí `index.html` en el navegador (o publicalo con GitHub Pages).
2. Tocá **Configurar IA** y completá formato del servicio, URL, modelo y clave.
3. Elegí grado y área, escribí la consulta y tocá **Generar proyecto**.

Opcional: en «Configurar IA» podés pegar extractos del Diseño Curricular y de los NAP para que el modelo los priorice.

### Sobre la clave API

La configuración se guarda solo en el navegador de quien la carga. **No subas claves al repositorio.** Una clave dentro de una página puede ser vista por quien use el equipo; para uso institucional conviene un servidor intermedio que guarde la clave y dejar el campo de clave vacío.

## Contenido del repositorio

| Ruta | Qué es |
|---|---|
| `index.html` | La aplicación completa (chat, base interna de 30 proyectos, conexión al modelo) |
| `docs/guia-continuidad.html` | Estado del proyecto, pendientes y prompt para retomar el trabajo en otra cuenta |

## Agregar proyectos a la base interna

En `index.html`, dentro del arreglo `D`, sumá una línea con este formato:

```js
["N","5.°","5 sem.","Título","Descripción breve.","palabras clave separadas por espacios"]
```

Códigos de área: `L` Lengua, `M` Matemática, `S` Ciencias Sociales, `N` Ciencias Naturales, `T` Educación Tecnológica, `A` Educación Artística, `F` Educación Física, `E` Formación Ética y Ciudadana.

## Estado y pendientes

- Falta recuperar la versión con el **Calendario** por área y grado, que no está en este archivo.
- Cargar calendarizaciones pendientes: Música, Artes Visuales, Folclore y Formación Ética (Segundo Ciclo), y Matemática, Naturales y Sociales de 1.° a 3.° (Primer Ciclo).
- Conectar el Calendario con la Biblioteca de Proyectos.
- Integrar «Marco legal» y «Libros».
- Validación por docentes de cada ciclo y autorización de Dirección.

## Publicar con GitHub Pages

En el repositorio: *Settings → Pages → Deploy from a branch → `main` / `(root)`*. La app queda disponible en una dirección web que se puede compartir con los docentes.
